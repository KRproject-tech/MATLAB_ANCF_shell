clc

addpath ./src

L1 = 1.0;
L2 = 1.0;

tmax = 500;
pi = 3.142;

t = [0 tmax];
x0 = [0.01 0.1 0 0];
[t,x] = ode45('funct',t,x0);
figure(1);
plot(t,x(:,2));
grid on; 
xlabel('time[s]');
ylabel('angle displacement[rad]');

% Animation Loop
figure(2);
set(1,'doublebuffer','on');
count=1;

for t = 1:4:tmax
    
    x_1 = L1*cos(x(t,1) - pi/2);
    y_1 = L1*sin(x(t,1) - pi/2);
    x_2 = x_1 + L2*cos(x(t,2) - pi/2);
    y_2 = y_1 + L2*sin(x(t,2) - pi/2);
    plot([0 x_1],[0 y_1],'-');
    hold on;
    plot([x_1 x_2],[y_1 y_2],'-');
    hold on;
    plot(x_1,y_1,'.k','MarkerSize',30);
    hold on;
    plot(x_2,y_2,'.k','MarkerSize',30);
    grid on; 
    xlim([-2.5 2.5]);
    ylim([-2.5 2.5]); 
    xlabel('x[m]');
    ylabel('y[m]');
    % �`��������X�V
    drawnow 
    hold off
   % pause(0.2)          % �������ɂ��邽�߂�pause�ŏ�����~
   
   data(count) = getframe(gcf);
   count=count+1;
end
mpgwrite(data,jet,'data.mpg')