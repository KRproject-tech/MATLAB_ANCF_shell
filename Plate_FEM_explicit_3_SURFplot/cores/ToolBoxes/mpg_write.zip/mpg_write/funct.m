function dx = funct(t,x)
dx = zeros(4,1);

%��d�U��q�̕�����
m1 = 1.0;%mass[kg]
m2 = 1.0;
L1 = 1.0;%length[m]
L2 = 1.0;
g = 9.8;%�d�͉����x[m/s]
Kgain = 9.8;%feed back gain

F_1 = Kgain*(x(1)-x(2));%feed back torque

m12 = m1 + m2;

%x1=��1,x2=��2,x3=d��1/dt,x4=d��2/dt,
dx(1) = x(3);
dx(2) = x(4);
dx(3) = ( -m2*L1*L2*sin(x(1)-x(2))*m2*L2^2*x(4)^2 - m2^2*L1^2*L2^2*cos(x(1)-x(2))*sin(x(1)-x(2))*x(3)^2 - m12*g*sin(x(1))*m2*L2^2 + m2^2*g*L1*L2^2*cos(x(1)-x(2))*sin(x(2)) + m2*L2^2*F_1) /(m12*L1^2*m2*L2^2 - m2^2*L1^2*L2^2*cos(x(1)-x(2))^2);
dx(4) = ( -m2^2*L1^2*L2^2*cos(x(1)-x(2))*sin(x(1)-x(2))*x(4)^2 - m12*L1^2*m2*L1*L2*sin(x(1)-x(2))*x(3)^2 - m12*m2*g*L1^2*L2*cos(x(1)-x(2))*sin(x(1)) + m12*L1^2*m2*g*L2*sin(x(2)) + m2*L1*L2*cos(x(1)-x(2))*F_1)/(-m12*L1^2*m2*L2^2 + m2^2*L1^2*L2^2*cos(x(1)-x(2))^2);

